OpenPyxl is a Python library to read/write Excel 2010 xlsx/xlsm files.

It was born from lack of existing library to read/write natively from Python the new Office Open XML format.

All kudos to the PHPExcel team as openpyxl is based on PHPExcel http://www.phpexcel.net/

== Mailing List ==

Official user list can be found on http://groups.google.com/group/openpyxl-users

== Official documentation ==

The homepage is http://openpyxl.readthedocs.org
You will find:

* every installation methods
* the official documentation
* code examples
* instructions for contributing


1.8.0 (unreleased)
==================

Compatibility
-------------

Support for Python 2.5 dropped.

Major changes
-------------

* Support conditional formatting
* Support lxml as backend
* Support reading and writing comments
* pytest as testrunner now required
* Improvements in charts: new types, more reliable


Minor changes
-------------

* load_workbook now accepts data_only to allow extracting values only from
formulae. Default is false.
* Images can now be anchored to cells
* Docs updated
* Provisional benchmarking
* Added convenience methods for accessing worksheets and cells by key


1.7.0 (2013-10-31)
==================


Major changes
-------------

Drops support for Python < 2.5 and last version to support Python 2.5


Compatibility
-------------

Tests run on Python 2.5, 2.6, 2.7, 3.2, 3.3


Merged pull requests
--------------------

#27 Include more metadata
#41 Able to read files with chart sheets
#45 Configurable Worksheet classes
#3 Correct serialisation of Decimal
#36 Preserve VBA macros when reading files
#44 Handle empty oddheader and oddFooter tags
#43 Fixed issue that the reader never set the active sheet
#33 Reader set value and type explicitly and TYPE_ERROR checking
#22 added page breaks, fixed formula serialization
#39 Fix Python 2.6 compatibility
#47 Improvements in styling


Known bugfixes
--------------

#109
#165
#179
#209
#112
#166
#109
#223
#124
#157


Miscellaneous
-------------

Performance improvements in optimised writer

Docs updated


